<?php $__env->startSection('content'); ?>
    <style>
        #rcorners1 {
            border-radius: 25px;
        }
    </style>

    <?php
        $first_name = App\Http\Controllers\UserController::username();
        $logo = App\Http\Controllers\UserController::logo();
        $dashboard_included = false; // To ensure only one dashboard is shown
    ?>

    <br>

    
    <?php if(!$dashboard_included && Gate::allows('admin-dashboard')): ?>
        <?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('super-authoriser-dashboard')): ?>
        <?php echo $__env->make('dashboard.authoriser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('finance-officer-dashboard')): ?>
        <?php echo $__env->make('dashboard.finance_officer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('purchasing-officer-dashboard')): ?>
        <?php echo $__env->make('dashboard.purchasing_officer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('requester-dashboard')): ?>
        <?php echo $__env->make('dashboard.requester', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('site-admin-dashboard')): ?>
        <?php echo $__env->make('dashboard.site_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('store-officer-dashboard')): ?>
        <?php echo $__env->make('dashboard.store_officer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('super-admin-dashboard')): ?>
        <?php echo $__env->make('dashboard.super_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <?php if(!$dashboard_included && Gate::allows('department-authoriser-dashboard')): ?>
        <?php echo $__env->make('dashboard.department_authoriser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php $dashboard_included = true; ?>
    <?php endif; ?>

    <script>
        setTimeout(function() {
            window.location.reload();
        }, 60000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nurudin/Documents/Projects/inventory-v2/resources/views/home.blade.php ENDPATH**/ ?>