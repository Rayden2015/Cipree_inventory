<?php $__env->startSection('content'); ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
        <link rel="stylesheet"
            href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

        <!-- Font Awesome -->
        <link rel="stylesheet" href="<?php echo e(asset('/assets/plugins/fontawesome-free/css/all.min.css')); ?>">
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo e(asset('/assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
        <link rel="stylesheet"
            href="<?php echo e(asset('/assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo e(asset('/assets/dist/css/adminlte.min.css')); ?>">

        <title>Received History</title>

    </head>

    <body>
        <div class="title d-flex justify-content-between">
            <h3 class="page-title"></h3>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-grn')): ?>
                <p>
                    <a href="<?php echo e(route('inventories.create')); ?>" class="btn btn-primary mr-3 my-3">Add</a>
                </p>
            <?php endif; ?>
        </div>

        <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Received History</h3>
                <form action="<?php echo e(route('inventory_history_search')); ?>" method="GET">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Search Description,Stock Code, Part No, PO Number, Enduser"
                            aria-describedby="basic-addon2" name="search">
                        <div class="input-group-append">
                            <button class="btn btn-secondary" type="submit">Search</button>
                        </div>
                    </div>
                </form>
                
                <form action="inventory_history_date_search" method="GET">
                    <div class="row">
                        <div class="input-group mb-3" style="width:99%; padding-left: 10px;">
                            <input type="date" class="form-control" name="start_date" required>
                            <input type="date" class="form-control" name="end_date" required>
                            <button class="btn btn-primary ml-2" type="submit">Submit</button>
                            <a class="btn btn-secondary ml-2" href="<?php echo e(route('inventories.inventory_item_history')); ?>">Clear</a>
                        </div>
                    </div>
                </form>
            </div>

            <!-- /.card-header -->

            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Received Date</th>
                            <th>End User</th>
                            <th>Purchase Order No.</th>
                            <th>Item Description</th>
                            <th>Item Code</th>
                            <th>Qty Received</th>
                            <th>Amount</th>
                            <th>GRN</th>
                            <th>Location</th>
                          

                           
                        </tr>
                    </thead>
                    <?php $__empty_1 = true; $__currentLoopData = $inventory_item_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tbody>
                            <tr>
                                <td><?php echo e($in->id); ?></td>
                                <td><?php echo e(date('d-m-Y (H:i)', strtotime($in->created_at))); ?></td>
                                <td><?php echo e($in->inventory->enduser->asset_staff_id ?? ''); ?></td>
                                <td><?php echo e($in->inventory->po_number ?? ''); ?></td>
                                <td><?php echo e($in->item->item_description ?? ''); ?></td>
                                <td><?php echo e($in->item->item_stock_code ?? ''); ?></td>
                                <td><?php echo e($in->quantity ?? ''); ?></td>
                                <td><?php echo e($in->amount ?? ''); ?></td>
                                <td>
                                    <a href="<?php echo e(route('inventories.show', ['inventory' => $in->inventory_id])); ?>">
                                        <?php echo e($in->inventory->grn_number ?? ''); ?>

                                    </a>
                                </td>
                                
                                <td><?php echo e($in->location->name ?? ''); ?></td>                             
                               
                             
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-center" colspan="12">Item not available!</td>
                            </tr>
                    <?php endif; ?>

                    </tr>
                    </tbody>

                </table>
            </div>
            <?php echo e($inventory_item_history->links('pagination::bootstrap-4')); ?>

            <!-- /.card-body -->
        </div>




    </body>
    <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
    <script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
    <?php echo Toastr::message(); ?>


    </html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nurudin/Documents/Projects/inventory-v2/resources/views/inventories/history.blade.php ENDPATH**/ ?>