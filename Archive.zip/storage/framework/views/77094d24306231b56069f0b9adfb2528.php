<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-alert-triangle" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                <path d="M12 9v4"></path>
                                <path d="M10.363 3.591l-8.106 13.534a1.914 1.914 0 0 0 1.636 2.871h16.214a1.914 1.914 0 0 0 1.636 -2.87l-8.106 -13.536a1.914 1.914 0 0 0 -3.274 0z"></path>
                                <path d="M12 16h.01"></path>
                            </svg>
                            Recent Error Logs
                            <small class="text-muted">(Newest First)</small>
                        </h3>
                        <div class="ms-auto">
                            <span class="badge bg-red text-white"><?php echo e(isset($errorLogs) && method_exists($errorLogs, 'total') ? $errorLogs->total() : 0); ?> Total Errors</span>
                        </div>
                    </div>

                    <?php if(isset($table_missing) && $table_missing): ?>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <strong>Warning!</strong> The error_logs table does not exist yet. Run the migration to create it:
                            <br><code>php artisan migrate --path=database/migrations/2024_07_07_073419_create_error_logs_table.php</code>
                        </div>
                    </div>
                    <?php else: ?>

                    <!-- Search Form -->
                    <div class="card-body border-bottom">
                        <form action="<?php echo e(route('error-logs.search')); ?>" method="GET">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label">Error ID</label>
                                    <input type="text" name="error_id" class="form-control" placeholder="762253241" value="<?php echo e(request('error_id')); ?>">
                                    <small class="text-muted">9-digit error ID shown to users</small>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">User</label>
                                    <select name="user_id" class="form-select">
                                        <option value="">All Users</option>
                                        <?php $__currentLoopData = $users ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user['id']); ?>" <?php echo e(request('user_id') == $user['id'] ? 'selected' : ''); ?>>
                                                <?php echo e($user['name']); ?> (ID: <?php echo e($user['id']); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <small class="text-muted">Filter errors by user</small>
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Controller</label>
                                    <input type="text" name="controller" class="form-control" placeholder="UserController" value="<?php echo e(request('controller')); ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Date From</label>
                                    <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
                                </div>
                                <div class="col-md-2">
                                    <label class="form-label">Date To</label>
                                    <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
                                </div>
                            </div>
                            <div class="row g-3 mt-2">
                                <div class="col-md-12">
                                    <div class="d-flex gap-2">
                                        <button type="submit" class="btn btn-primary">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" /><path d="M21 21l-6 -6" /></svg>
                                            Search
                                        </button>
                                        <a href="<?php echo e(route('error-logs.index')); ?>" class="btn btn-link">Clear Filters</a>
                                        <?php if(request()->hasAny(['error_id', 'user_id', 'controller', 'date_from', 'date_to'])): ?>
                                            <span class="badge bg-blue align-self-center ms-2">Active Filters</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- Legacy File Search -->
                    <div class="card-body border-bottom bg-light">
                        <div class="row align-items-center">
                            <div class="col">
                                <strong>Search Legacy Log Files</strong>
                                <small class="text-muted d-block">For errors before database logging was enabled</small>
                            </div>
                            <div class="col-auto">
                                <form action="<?php echo e(route('error-logs.search-files')); ?>" method="GET" class="d-flex gap-2">
                                    <input type="text" name="error_id" class="form-control" placeholder="Error ID" required style="width: 200px;">
                                    <button type="submit" class="btn btn-secondary">Search Files</button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Error Logs Table -->
                    <div class="table-responsive">
                        <table class="table table-vcenter card-table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Date/Time</th>
                                    <th>User</th>
                                    <th>Level</th>
                                    <th>Message</th>
                                    <th>IP Address</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $errorLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $context = json_decode($log->context, true) ?? [];
                                    $userName = $context['user_name'] ?? 'Unknown';
                                    $userId = $context['user_id'] ?? 'N/A';
                                ?>
                                <tr>
                                    <td class="text-muted"><?php echo e($log->id); ?></td>
                                    <td>
                                        <span class="text-muted"><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('d-M-Y')); ?></span><br>
                                        <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($log->created_at)->format('H:i:s')); ?></small>
                                    </td>
                                    <td>
                                        <strong><?php echo e($userName); ?></strong><br>
                                        <small class="text-muted">ID: <?php echo e($userId); ?></small>
                                    </td>
                                    <td>
                                        <?php if($log->level_name == 'ERROR'): ?>
                                            <span class="badge bg-red"><?php echo e($log->level_name); ?></span>
                                        <?php elseif($log->level_name == 'WARNING'): ?>
                                            <span class="badge bg-yellow"><?php echo e($log->level_name); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-blue"><?php echo e($log->level_name); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="text-truncate" style="max-width: 400px;">
                                            <?php echo e($log->message); ?>

                                        </div>
                                        <?php if(preg_match('/ERROR_ID:(\d+)/', $log->message, $matches)): ?>
                                            <span class="badge bg-orange mt-1">Error ID: <?php echo e($matches[1]); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($log->remote_addr): ?>
                                            <code><?php echo e($log->remote_addr); ?></code>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('error-logs.show', $log->id)); ?>" class="btn btn-sm btn-primary">
                                            View Details
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-lg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M8 8a3.5 3 0 0 1 3.5 -3h1a3.5 3 0 0 1 3.5 3a3 3 0 0 1 -2 3a3 4 0 0 0 -2 4" /><path d="M12 19l0 .01" /></svg>
                                        <p class="h3">No error logs found!</p>
                                        <p class="text-muted">
                                            <?php if(request()->hasAny(['error_id', 'user_id', 'controller', 'date_from', 'date_to'])): ?>
                                                No errors match your search criteria.
                                            <?php else: ?>
                                                Great news! No errors have been logged yet.
                                            <?php endif; ?>
                                        </p>
                                        <?php if(request()->hasAny(['error_id', 'user_id', 'controller', 'date_from', 'date_to'])): ?>
                                            <a href="<?php echo e(route('error-logs.index')); ?>" class="btn btn-primary btn-sm">View All Errors</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if(isset($errorLogs) && method_exists($errorLogs, 'hasPages') && $errorLogs->hasPages()): ?>
                    <div class="card-footer">
                        <?php echo e($errorLogs->links()); ?>

                    </div>
                    <?php endif; ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/nurudin/Documents/Projects/inventory-v2/resources/views/errors/logs/index.blade.php ENDPATH**/ ?>