<?php

namespace App\Traits;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use App\Models\ErrorLog;

trait LogsErrors
{
    /**
     * Log an error with comprehensive context
     *
     * @param \Exception $exception The exception that was thrown
     * @param string $action The action/method being performed (e.g., "Store()", "Update()")
     * @param array $additionalContext Any additional context to log
     * @return int The unique error ID
     */
    public function logError(\Exception $exception, string $action, array $additionalContext = []): int
    {
        $unique_id = floor(time() - 999999999);
        
        // Get controller name from the calling class
        $controller = class_basename($this);
        
        // Build comprehensive error context
        $context = array_merge([
            'error_id' => $unique_id,
            'controller' => $controller,
            'method' => $action,
            'user_id' => Auth::id() ?? null,
            'user_name' => Auth::user()->name ?? 'guest',
            'user_email' => Auth::user()->email ?? null,
            'url' => request()->fullUrl(),
            'http_method' => request()->method(),
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'error_message' => $exception->getMessage(),
            'error_file' => $exception->getFile(),
            'error_line' => $exception->getLine(),
            'error_code' => $exception->getCode(),
            'stack_trace' => $exception->getTraceAsString(),
            'request_data' => request()->except(['password', 'password_confirmation', '_token', 'image']),
            'timestamp' => now()->toDateTimeString()
        ], $additionalContext);
        
        $logMessage = "[ERROR_ID:{$unique_id}] {$controller} | {$action} | {$exception->getMessage()}";
        
        // Log to file
        Log::channel('error_log')->error($logMessage, $context);
        
        // Log to database if table exists
        if (Schema::hasTable('error_logs')) {
            try {
                ErrorLog::create([
                    'message' => $logMessage,
                    'context' => json_encode($context),
                    'level' => 500, // ERROR level
                    'level_name' => 'ERROR',
                    'channel' => 'error_log',
                    'record_datetime' => now()->toDateTimeString(),
                    'extra' => json_encode([]),
                    'formatted' => $exception->getMessage() . "\n" . $exception->getTraceAsString(),
                    'remote_addr' => $context['ip_address'],
                    'user_agent' => $context['user_agent'],
                ]);
            } catch (\Throwable $dbException) {
                // If database logging fails, log to file only
                Log::warning('Failed to log error to database', [
                    'original_error_id' => $unique_id,
                    'db_error' => $dbException->getMessage()
                ]);
            }
        }
        
        return $unique_id;
    }
    
    /**
     * Get standardized error message for users
     *
     * @param int $errorId The unique error ID
     * @return string The user-friendly error message
     */
    public function getUserErrorMessage(int $errorId): string
    {
        return "An error occurred. Please contact the Administrator with error ID: {$errorId} via the error code and Feedback Button.";
    }
    
    /**
     * Log and return error response
     *
     * @param \Exception $exception The exception that was thrown
     * @param string $action The action/method being performed
     * @param array $additionalContext Any additional context to log
     * @return \Illuminate\Http\RedirectResponse
     */
    public function handleError(\Exception $exception, string $action, array $additionalContext = [])
    {
        $errorId = $this->logError($exception, $action, $additionalContext);
        
        return redirect()->back()
            ->withInput()
            ->withError($this->getUserErrorMessage($errorId));
    }
}

