<?php

return [
    'failed' => 'These credentials do not match our records.',
    'throttle' => 'Wrong Password, please try again.',
];
