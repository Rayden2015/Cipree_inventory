<!DOCTYPE html>
<html>
<head>
    <title>Bulk Email</title>
</head>
<body>
    {{-- <h1>Mail from</h1> --}}
    <p>{{ $content }}</p>
</body>
</html>
