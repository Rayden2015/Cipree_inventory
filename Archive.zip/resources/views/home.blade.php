@extends('layouts.admin')

@section('content')
    <style>
        #rcorners1 {
            border-radius: 25px;
        }
    </style>

    @php
        $first_name = App\Http\Controllers\UserController::username();
        $logo = App\Http\Controllers\UserController::logo();
        $dashboard_included = false; // To ensure only one dashboard is shown
    @endphp

    <br>

    {{-- Dashboard Inclusions --}}
    @if (!$dashboard_included && Gate::allows('admin-dashboard'))
        @include('dashboard.admin')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('super-authoriser-dashboard'))
        @include('dashboard.authoriser')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('finance-officer-dashboard'))
        @include('dashboard.finance_officer')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('purchasing-officer-dashboard'))
        @include('dashboard.purchasing_officer')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('requester-dashboard'))
        @include('dashboard.requester')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('site-admin-dashboard'))
        @include('dashboard.site_admin')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('store-officer-dashboard'))
        @include('dashboard.store_officer')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('super-admin-dashboard'))
        @include('dashboard.super_admin')
        @php $dashboard_included = true; @endphp
    @endif

    @if (!$dashboard_included && Gate::allows('department-authoriser-dashboard'))
        @include('dashboard.department_authoriser')
        @php $dashboard_included = true; @endphp
    @endif

    <script>
        setTimeout(function() {
            window.location.reload();
        }, 60000);
    </script>
@endsection
