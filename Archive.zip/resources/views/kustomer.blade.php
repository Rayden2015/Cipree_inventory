<div id="kustomer">
    <kustomer
        :params="{{ json_encode(config('kustomer')) }}"
        :labels="{{ json_encode(trans('kustomer::kustomer')) }}">
</kustomer>
</div>